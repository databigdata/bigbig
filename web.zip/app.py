from flask import Flask, render_template, request, session, make_response

app = Flask(__name__)

# TODO 메뉴 레시피 화면
@app.route('/recipe', methods=['get'])
def showRecipe():
    from query import getRecipe
    a = request.args
    name = a['value']
    print(name)
    q = getRecipe(name)
    ingredient = q['ingredient']
    return render_template('single-recipe.html', menu=name, ingredient=ingredient)


@app.route('/<path>')
def hello_world(path=None):
    if path:
        return render_template('{}'.format(path))
    else:
        return render_template('index.html')




@app.route('/find', methods=['POST'])
def find():

    return render_template('index.html')



# TODO 추천지수 계산, 메뉴 리스트 출력
@app.route('/query', methods=['POST'])
def query():
    from query import query, temp, getRecommend, selectFood

    try:
        a = request.form['search']
        print('type(a)', type(a))
        print('a', a)
        n = a[-1]
        print('n', n)
    except:
        print('e')
        # a = request.a
        a = request.cookies.get('a')
        n = request.cookies.get('choice')
        print('cookie a', a)
        print('cookie n', n)

    try:
        b = request.form['order']
        print(b)
        if b == 'recommend':
            flag = '권장률'
        elif b == 'caution':
            flag = '위험률'
        elif b == 'rc':
            flag = '추천지수'
    except:
        print('error')
        flag = '권장률'

    try:
        foodName = request.form['food']
        print('foodName', foodName)
    except:
        try:
            foodName = request.cookies.get('foodName')
            print('cookie foodName', foodName)
        except:
            foodName = None

    data = a.split(', ')
    print(len(data))
    for i in data:
        print(i)


    if n == "1" : # 먹고 싶은 음식 있을 때
        if len(data) == 1 or len(data) == 2:
            q = query(data[0])
            recommend, caution = getRecommend(data[0])
            # print(q)

            if flag == '위험률':
                recommend_rate = sorted(q, key=lambda k: q[k][flag])  # 추천지수 계산 오름차순
            else:
                recommend_rate = sorted(q, key=lambda k: q[k][flag], reverse=True)  # 추천지수 계산 내림차순
            print(type(recommend_rate))
            print(recommend_rate)

            resp = make_response(
                render_template('index.html', dname=data[0], recommend=recommend, caution=caution, rate=recommend_rate,
                                data=q))
            resp.set_cookie('a', a)
            resp.set_cookie('choice', n)
            if foodName :
                food = selectFood(foodName, q)
                print('food : ' , food)
                resp.set_cookie('foodName', foodName)
            return resp
        else:
            q = temp(data[0], data[1])
            recommend1, caution1 = getRecommend(data[0])
            recommend2, caution2 = getRecommend(data[1])
            # print(q)
            if flag == '위험률':
                recommend_rate = sorted(q, key=lambda k: q[k][flag])
            else:
                recommend_rate = sorted(q, key=lambda k: q[k][flag], reverse=True)
            print(type(recommend_rate))
            print(recommend_rate)
            resp = make_response(render_template('index.html', dname1=data[0], dname2=data[1], recommend1=recommend1,
                                                 recommend2=recommend2, caution1=caution1, caution2=caution2,
                                                 rate=recommend_rate, data=q, foodName = foodName))
            resp.set_cookie('a', a)
            resp.set_cookie('choice', n)
            if foodName:
                resp.set_cookie('foodName', foodName)
            return resp
    else :  # 없을 때
        if len(data) == 1 or len(data) == 2:
            q = query(data[0])
            recommend, caution = getRecommend(data[0])
            # print(q)

            if flag == '위험률':
                recommend_rate = sorted(q, key=lambda k: q[k][flag])  # 추천지수 계산 오름차순
            else:
                recommend_rate = sorted(q, key=lambda k: q[k][flag], reverse=True)  # 추천지수 계산 내림차순
            print(type(recommend_rate))
            print(recommend_rate)

            resp = make_response(
                render_template('index2.html', dname=data[0], recommend=recommend, caution=caution, rate=recommend_rate,
                                data=q))
            resp.set_cookie('a', a)
            resp.set_cookie('choice', n)

            return resp
        else:
            q = temp(data[0], data[1])
            recommend1, caution1 = getRecommend(data[0])
            recommend2, caution2 = getRecommend(data[1])
            # print(q)
            if flag == '위험률':
                recommend_rate = sorted(q, key=lambda k: q[k][flag])
            else:
                recommend_rate = sorted(q, key=lambda k: q[k][flag], reverse=True)
            print(type(recommend_rate))
            print(recommend_rate)
            resp = make_response(render_template('index2.html', dname1=data[0], dname2=data[1], recommend1=recommend1,
                                                 recommend2=recommend2, caution1=caution1, caution2=caution2,
                                                 rate=recommend_rate, data=q))
            resp.set_cookie('a', a)
            resp.set_cookie('choice', n)
            return resp




if __name__ == '__main__':
    app.run()
