function addValue() {
    if (window.name != "") {
        if(window.document.getElementById("tag-input-33") != null)
            window.document.getElementById("tag-input-33").value = window.name;
        console.log("not null");
    }
    // console.log("onload1" + window.document.getElementById("tag-input-33").value);
    // console.log("onload2" + window.document.getElementsByClassName("close").value);
    // console.log("onload2" + window.document.getElementsByClassName("close"));
}


// 페이지 로드시
window.onload = addValue();


//페이지 벗어났을 때
window.onbeforeunload = function () {
    console.log(window.location.pathname);
    console.log(window.location.pathname.toString());
    console.log(window.location.pathname.toString().indexOf("query"));
    if((window.location.pathname.toString()).indexOf("query") == -1){
        window.name = "";
    }
    // if (document.readyState == "complete") {
    //     // 새로고침
    //     console.log("새로고침")
    // } else if (document.readyState == "loading") {
    //     // 다른사이트로 이동
    //     window.name = null;
    //     console.log("다른사이트로 이동");
    //     alert("다른사이트로 이동");
    // }

    // window.name=null;
    // alert("unload");
    // console.log("unload");
}

//보류
function bClick() {
    console.log("bClick");
}

//

window.document.getElementById("rc").addEventListener("click", bClick);
window.document.getElementById("recommend").addEventListener("click", bClick);
window.document.getElementById("caution").addEventListener("click", bClick);

(function () {
    $("#tag-input-33").tokenfield();

    $("#tokenlist-loaded").tokenfield();


    $("submit").on('click', function (e) {
        e.preventDefault();
        console.log("sdfs");
        console.log("1"+ window.document.getElementById("tag-input-33").value);
        console.log("3" + $("#tag-input-33").tokenfield('getTokensList'));
        var form = document.find;
        form.submit();
        if (window.name == null || window.name == "") {
            console.log('window.name null');
            window.name = window.document.getElementById("tag-input-33").value
        }
        else {
            window.name = window.document.getElementById("tag-input-33").value
            console.log('window.name : ' + window.name);

        }
        return $("#tokenlist-1").val($("#tag-input-33").tokenfield('getTokensList'));
    });

}).call(this);
