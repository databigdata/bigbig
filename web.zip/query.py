import pymongo

connection = pymongo.MongoClient("localhost", 27017)


def query(dname1): # 질병 하나 계싼
    print('q', dname1)
    db = connection.recipeDB2
    recipe = db.recipe
    food = db.food
    disease = db.disease

    foodDict = dict()
    for i in food.find():
        foodDict[i['food']] = i['element']

    dic = dict()

    cur = recipe.find()  # 레시피만 가져오기
    curdis1 = disease.find({'disease_name': {"$eq": dname1}})
    recommend1 = []
    bul1 = []

    # recommend1 = curdis1.next()['권장식품']
    # recommend2 = curdis2.next()['권장식품']
    for i in curdis1:
        recommend1.extend(i['권장식품'])
        bul1.extend(i['주의식품'])

    recommend = list(set(recommend1))
    c = recommend.copy()
    bul = list(set(bul1))

    recommend1 = recommend.copy()
    bul1 = bul.copy()

    nl = []
    cnt = 0
    error = []
    for recipe in cur:
        recipe_name = recipe['food_name']
        ho_count = 0
        bul_count = 0
        total_leng = len(recipe['ingredient'])
        for d in recipe['ingredient']:
            for ingredient in d:
                for i in recommend1:
                    try:
                        if ingredient in foodDict[i]:
                            ho_count = ho_count + 1
                            break
                    except:
                        # continue
                        if ingredient in i:
                            ho_count = ho_count + 1
                            break
                for j in bul1:
                    try:
                        if ingredient in foodDict[j]:
                            bul_count = bul_count + 1
                            break
                    except:
                        # continue
                        if ingredient in j:
                            bul_count = bul_count + 1
                            break
        try:
            p = ho_count / total_leng
            nl.append(p)
            q = bul_count / total_leng
            r = 1 - p - q
            #     print(count)
            dic[recipe_name] = {'권장률': p, '위험률': q, '추천지수': p - q}

            if p > 1:
                error.append(recipe_name)
                cnt = cnt + 1
        except:
            continue
            # print(recipe_name)
    return dic


def temp(dname1, dname2): # 질병 두개 계싼
    db = connection.recipeDB2
    recipe = db.recipe
    food = db.food
    disease = db.disease

    foodDict = dict()
    for i in food.find():
        foodDict[i['food']] = i['element']

    dic = dict()

    cur = recipe.find()  # 레시피만 가져오기
    curdis1 = disease.find({'disease_name': {"$eq": dname1}})
    curdis2 = disease.find({'disease_name': {"$eq": dname2}})
    recommend1 = []
    recommend2 = []
    bul1 = []
    bul2 = []

    # recommend1 = curdis1.next()['권장식품']
    # recommend2 = curdis2.next()['권장식품']
    for i in curdis1:
        recommend1.extend(i['권장식품'])
        bul1.extend(i['주의식품'])
    for i in curdis2:
        recommend2.extend(i['권장식품'])
        bul2.extend(i['주의식품'])

    recommend = list(set(recommend1 + recommend2))
    c = recommend.copy()
    bul = list(set(bul1 + bul2))
    for i in c:
        if i in bul:
            recommend.remove(i)

    recommend1 = recommend.copy()
    bul1 = bul.copy()

    nl = []
    cnt = 0
    error = []
    for recipe in cur:
        recipe_name = recipe['food_name']
        ho_count = 0
        bul_count = 0
        total_leng = len(recipe['ingredient'])
        for d in recipe['ingredient']:
            for ingredient in d:
                for i in recommend1:
                    try:
                        if ingredient in foodDict[i]:
                            ho_count = ho_count + 1
                            break
                    except:
                        # continue
                        if ingredient in i:
                            ho_count = ho_count + 1
                            break
                for j in bul1:
                    try:
                        if ingredient in foodDict[j]:
                            bul_count = bul_count + 1
                            break
                    except:
                        # continue
                        if ingredient in j:
                            bul_count = bul_count + 1
                            break
        try:
            p = ho_count / total_leng
            nl.append(p)
            q = bul_count / total_leng
            r = 1 - p - q
            #     print(count)
            dic[recipe_name] = {'권장률': p, '위험률': q, '추천지수': p - q}

            if p > 1:
                error.append(recipe_name)
                cnt = cnt + 1
        except:
            continue
            # print(recipe_name)
    return dic
    # print(cnt)
    # print(dic['초간단 순대국 만들기 뭐야.. 이 맛은'])
    # print(sorted(nl))


def getRecommend(dname): # 특정 메뉴의 권장/주의 식품 리턴
    db = connection.recipeDB2
    disease = db.disease
    d = disease.find({'disease_name' : {"$eq":dname}}).next()
    return d['권장식품'], d['주의식품']

def getRecipeAll(): #보류
    db = connection.recipeDB2
    return

def getRecipe(fname): # 특정 메뉴의 데이터를 읽어옴 single-recipe에서 레시피 보여줄 때 사용
    db = connection.recipeDB2
    recipe = db.recipe
    print(fname)

    data = recipe.find({'food_name' : {'$eq': fname}})
    print(data)
    print(data.count())
    data = data.next()
    print(data)
    return data

def selectFood(fnames, dic):
    result = []

    if type(fnames) == str:
        for i in dic:
            if fnames in i :
                print('func', i)
                result.append(dic[i])
    else:
        for i in dic:
            for j in fnames:
                if j in i:
                    print('func', i)
                    result.append(dic[i])

    return result


def selectIngre(ingredients, dic):

    db = connection.recipeDB2
    recipe = db.recipe

    plus_ingredient = ['두부', '육류', '어패류']
    minus_ingredient = ['술', '통조림류', '조리가공식품류', '당류']

    cur = recipe.find()
    filtering_recipe = {}
    break_flag = 0
    foodDict = dict()

    for recipe in cur:
        recipe_name = recipe['food_name']
        list_ingredient = []
        plus_flag = 0
        minus_flag = 0

        for d in recipe['ingredient']:
            for ingredient in d:
                list_ingredient.append(ingredient)

        for plus in plus_ingredient:
            try:
                for fd in foodDict[plus]:
                    for li in list_ingredient:
                        if fd in li:
                            plus_flag = plus_flag + 1
                            break_flag = 1
                            break
                    if break_flag == 1:
                        break_flag = 0
                        break
            except:
                for li in list_ingredient:
                    if plus in li:
                        plus_flag = plus_flag + 1

        for minus in minus_ingredient:
            try:
                for fd in foodDict[minus]:
                    for li in list_ingredient:
                        if fd in li:
                            break_flag = 1
                            break
                        else:
                            continue
                    if break_flag == 1:
                        break_flag = 0
                        break
                if fd is foodDict[minus][-1]:
                    minus_flag = minus_flag + 1

            except:
                for li in list_ingredient:
                    if minus in li:
                        break
                    else:
                        continue

                if li not in list_ingredient[0:-1]:
                    minus_flag = minus_flag + 1

        if plus_flag == len(plus_ingredient) and minus_flag == len(minus_ingredient):
            filtering_recipe[recipe_name] = dic[recipe_name]

    return filtering_recipe

